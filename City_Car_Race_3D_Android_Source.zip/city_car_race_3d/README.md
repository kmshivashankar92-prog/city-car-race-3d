# City Car Race 3D — Android-ready source project

A playable procedural 3D city-driving prototype written in C++ with raylib 5.x. The city is generated at runtime, so no external art/audio files are needed.

## Included systems

- Third-person 3D driving with touch joystick and on-screen controls; keyboard fallback for desktop.
- Procedural Indian-inspired city grid: roads, low-poly buildings, lane markings and street trees.
- Traffic cars, yellow taxis, buses, wandering pedestrians and animals.
- Wanted stars, police pursuit, police car lights and helicopter pursuit at 3+ stars.
- Health, collision damage, minimap and delivery missions with cash rewards.
- Garage with four car types, purchasing/equipping and speed upgrades.
- Save/load of money, car ownership, selected car, upgrades and high score.
- Procedurally generated engine and ambient chirp sounds.

## Important scope note

This is a complete **starter/prototype**, not a commercial-grade GTA-scale simulation. Models are procedural low-poly shapes; NPCs and traffic use simple AI; mission types are currently delivery missions. The on-screen ALARM button raises wanted level in this prototype; it does not fire projectiles. You can extend the systems without needing external assets first.

## Build on Windows/Linux/macOS (desktop test)

Requirements: Git, CMake 3.16+, and a C/C++ compiler.

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

Run `build/city_car_race` (Windows may place it under `build/Release/`). The first CMake configure downloads raylib 5.5 from its official repository, so an internet connection is needed once.

## Build an Android APK with Android Studio (recommended)

Use the raylib Android Studio template as the Android shell; this avoids fragile manual APK packaging and supplies the native activity, Gradle files and NDK configuration.

1. Install **Android Studio**, Android SDK Platform (API 35 or the latest stable offered), Android SDK Build-Tools, and the Android NDK/CMake components from **Tools → SDK Manager → SDK Tools**. Install a JDK supported by your Android Studio version.
2. Download/clone the raylib Android template, for example the Raymob Android Studio template: `https://github.com/Bigfoot71/raymob` (the raymob README documents its SDK/NDK requirements and native source folder).
3. Open the template project in Android Studio and let Gradle sync complete. Confirm its native CMake target already builds the bundled raylib library.
4. Back up the template's sample C/C++ game source. Copy this project's `main.cpp` into the template's native source folder (commonly `app/src/main/cpp/` or `app/cpp/`, depending on the template).
5. Update the template's `CMakeLists.txt` so its executable/shared-library target compiles `main.cpp` and links raylib. Keep the target/library name expected by the template's `AndroidManifest.xml`/NativeActivity. Do not replace the template's Android glue or Gradle files.
6. If the template compiles as C, change the source target to C++ (`main.cpp`), set C++17 in CMake, and ensure the target links the C++ runtime as the template expects. Keep `raylib` linked to the native target.
7. In the template's `AndroidManifest.xml`, use landscape orientation for this driving game (e.g. `android:screenOrientation="landscape"`) if not already set. The game requests no special permissions; save data is written to the app's writable working directory.
8. Connect an Android phone with USB debugging enabled, or start an emulator. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
9. Android Studio reports the generated APK location, typically `app/build/outputs/apk/debug/app-debug.apk`. Install it from Android Studio or copy it to the phone and allow installation from that source.
10. For a release build, create your own signing key under **Build → Generate Signed Bundle / APK**. Keep the keystore and passwords private.

### Native CMake target example

If the template's CMake file already defines raylib, the essential target lines are similar to:

```cmake
add_library(main SHARED main.cpp)
target_compile_features(main PRIVATE cxx_std_17)
target_link_libraries(main raylib android log EGL GLESv2 OpenSLES dl)
```

The target name may need to remain `main` for the template. Do **not** paste this blindly over the template's complete CMake file: preserve its raylib source/library setup and Android-specific configuration.

## Android build references

- Official raylib repository and platform guidance: https://github.com/raysan5/raylib
- Official raylib Android example Makefile: https://github.com/raysan5/raylib/blob/master/examples/Makefile.Android
- raylib Android build notes: https://github.com/raysan5/raylib/wiki/Working-for-Android

Template folder layouts change over time; use the exact native source folder and library target name already present in the template you download.

## Controls

- **Touch:** left side drag joystick; right side ALARM, BRAKE, GARAGE, MISSION.
- **Keyboard:** WASD/arrows drive, Space BOOST, G garage, M mission, Esc garage toggle, Enter restart after game over.
- **Garage:** select a car row to buy/equip; tap the equipped row again (or click it on desktop) to buy a speed upgrade for $1,000.
- **Mission:** press M or tap MISSION, then drive to the gold marker before time expires.

## Notes

- This environment did not compile an Android APK. The source is provided as a project archive; use Android Studio/NDK to produce and test the APK on your device.
- The saved data format is a small local binary struct. If you change `SaveData`, consider versioning the save format before releasing updates.
