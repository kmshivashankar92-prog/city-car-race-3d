// City Car Race 3D - Android-first starter project
// Engine: raylib 5.x. Procedural low-poly city; no external assets required.
#include "raylib.h"
#include "raymath.h"
#include <vector>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <algorithm>

static constexpr float ROAD_SPACING = 100.0f;
static constexpr float ROAD_WIDTH = 18.0f;
static constexpr int GRID = 10;
static constexpr float WORLD_HALF = ROAD_SPACING * GRID * 0.5f;
static const char *SAVE_FILE = "citycar_save.dat";

static float RandF(float a, float b) { return a + (b-a)*(GetRandomValue(0,10000)/10000.0f); }
static float ClampF(float v,float a,float b) { return v<a?a:(v>b?b:v); }
static float WrapAngle(float a) { while(a>PI) a-=2*PI; while(a<-PI) a+=2*PI; return a; }
static Vector3 Forward(float yaw) { return {sinf(yaw),0,cosf(yaw)}; }
static float DistXZ(Vector3 a, Vector3 b) { float x=a.x-b.x,z=a.z-b.z; return sqrtf(x*x+z*z); }
static bool OnRoad(float x,float z) {
    for(int i=-GRID/2;i<=GRID/2;i++) { float p=i*ROAD_SPACING; if(fabsf(x-p)<ROAD_WIDTH*0.5f || fabsf(z-p)<ROAD_WIDTH*0.5f) return true; }
    return false;
}
struct CarSpec { const char* name; float maxSpeed, accel, handling; int price; Color color; };
static const CarSpec CARS[4] = {
    {"CITY SEDAN", 32, 18, 1.9f, 0, RED},
    {"SPORTS CAR", 44, 24, 2.25f, 2500, SKYBLUE},
    {"MUSCLE CAR", 38, 27, 1.65f, 5000, ORANGE},
    {"SUPER CAR", 52, 29, 2.4f, 10000, PURPLE}
};
struct Player { Vector3 pos{0,0,0}; float yaw=0, speed=0, health=100; };
struct Traffic { Vector3 pos; int axis; int dir; float speed; Color color; int kind; };
struct Person { Vector3 pos; Vector3 vel; Color color; float timer; };
struct Animal { Vector3 pos; Vector3 vel; float timer; };
struct Cop { Vector3 pos; float yaw=0, speed=0, fireTimer=1; };
struct Bullet { Vector3 pos, vel; float life; bool player; };
struct Building { Vector3 pos; Vector3 size; Color color; };
struct SaveData { int money=0, owned=1, car=0, upgrades=0, highScore=0; };
struct TouchUI { Vector2 joyBase{105,0}, joyKnob{105,0}; bool joyActive=false; int joyId=-1; float steer=0, throttle=0; bool brake=false, fire=false, garage=false, mission=false; };

static SaveData saveData;
static void SaveGame(){ SaveFileData(SAVE_FILE, &saveData, sizeof(saveData)); }
static void LoadGame(){ int n=0; unsigned char *p=LoadFileData(SAVE_FILE,&n); if(p && n==(int)sizeof(saveData)) { memcpy(&saveData,p,sizeof(saveData)); UnloadFileData(p); } if(saveData.car<0||saveData.car>3) saveData.car=0; if(saveData.money<0)saveData.money=0; saveData.owned|=1; }
static void DrawCar3D(Vector3 p,float yaw,Color c,float length=4.2f,float width=2.0f) {
    Vector3 f=Forward(yaw); Vector3 right={f.z,0,-f.x};
    DrawCube(p,width,1.0f,length,c);
    Vector3 cabin=Vector3Add(p,Vector3Scale(f,-0.35f)); cabin.y+=0.72f;
    DrawCube(cabin,width*0.72f,0.62f,length*0.42f,Color{150,205,220,255});
    for(int sx=-1;sx<=1;sx+=2) for(int sz=-1;sz<=1;sz+=2) {
        Vector3 w=Vector3Add(p,Vector3Add(Vector3Scale(right,sx*(width*0.52f)),Vector3Scale(f,sz*(length*0.32f)))); w.y-=0.30f;
        DrawCube(w,0.28f,0.48f,0.72f,DARKGRAY);
    }
    Vector3 front=Vector3Add(p,Vector3Scale(f,length*0.51f)); front.y+=0.05f;
    DrawCube(front,width*0.65f,0.16f,0.12f,YELLOW);
}
static void DrawPerson(const Person& n){ DrawCylinder({n.pos.x,n.pos.y+0.65f,n.pos.z},0.24f,0.20f,1.3f,6,n.color); DrawSphere({n.pos.x,n.pos.y+1.48f,n.pos.z},0.22f,BEIGE); }
static void DrawAnimal(const Animal& a){ DrawCube({a.pos.x,a.pos.y+0.32f,a.pos.z},0.9f,0.55f,0.45f,BROWN); DrawSphere({a.pos.x+0.42f,a.pos.y+0.48f,a.pos.z},0.22f,BEIGE); }
static void DrawCop3D(const Cop& c,float t){ DrawCar3D(c.pos,c.yaw,{25,35,75,255},4.4f,2.1f); Color flash=((int)(t*7)%2)?RED:BLUE; DrawCube({c.pos.x,c.pos.y+0.72f,c.pos.z},0.75f,0.16f,0.35f,flash); }
static void DrawHeli(Vector3 p,float t){ DrawCube({p.x,p.y,p.z},2.5f,0.85f,3.6f,DARKGRAY); DrawCube({p.x,p.y,p.z-2.5f},0.35f,0.25f,2.0f,DARKGRAY); DrawCube({p.x,p.y+0.65f,p.z},5.5f,0.08f,0.12f,LIGHTGRAY); DrawCube({p.x,p.y+0.68f,p.z},0.12f,0.08f,5.5f,LIGHTGRAY); DrawSphere({p.x,p.y-0.55f,p.z},0.8f,Fade(YELLOW,0.14f)); (void)t; }
static void DrawMinimap(Player p,const std::vector<Traffic>& traffic,const std::vector<Cop>& cops,int sw) {
    const int x=sw-155,y=18,s=132; DrawRectangle(x,y,s,s,Fade(BLACK,0.65f));
    for(int i=-GRID/2;i<=GRID/2;i++){int q=x+s/2+(int)(i*ROAD_SPACING/WORLD_HALF*s*0.5f); DrawLine(q,y,q,y+s,Fade(LIGHTGRAY,0.55f)); DrawLine(x,y+s/2+(int)(i*ROAD_SPACING/WORLD_HALF*s*0.5f),x+s,y+s/2+(int)(i*ROAD_SPACING/WORLD_HALF*s*0.5f),Fade(LIGHTGRAY,0.55f));}
    auto dot=[&](Vector3 v,Color c,int r){int px=x+s/2+(int)(v.x/WORLD_HALF*s*0.5f),py=y+s/2+(int)(v.z/WORLD_HALF*s*0.5f); DrawCircle(px,py,r,c);};
    for(auto &v:traffic) dot(v.pos,GRAY,2); for(auto &c:cops)dot(c.pos,RED,3); dot(p.pos,GREEN,4); DrawRectangleLines(x,y,s,s,WHITE);
}

int main(){
    InitWindow(1280,720,"City Car Race 3D - India Open World"); SetTargetFPS(60); InitAudioDevice(); SetRandomSeed((unsigned int)time(nullptr)); LoadGame();
    Player player; player.pos={0,0,0};
    std::vector<Building> buildings; std::vector<Traffic> traffic; std::vector<Person> people; std::vector<Animal> animals; std::vector<Cop> cops; std::vector<Bullet> bullets;
    for(int x=-GRID/2;x<=GRID/2;x++) for(int z=-GRID/2;z<=GRID/2;z++) {
        for(int k=0;k<3;k++) { float bx=x*ROAD_SPACING+RandF(ROAD_WIDTH,ROAD_SPACING-ROAD_WIDTH), bz=z*ROAD_SPACING+RandF(ROAD_WIDTH,ROAD_SPACING-ROAD_WIDTH); if(DistXZ({bx,0,bz},{0,0,0})<28)continue; Building b; b.pos={bx,0,bz}; b.size={RandF(9,24),RandF(8,35),RandF(9,24)}; b.pos.y=b.size.y/2; int palette=GetRandomValue(0,4); b.color=palette==0?Color{205,177,140,255}:palette==1?Color{180,195,205,255}:palette==2?Color{218,202,165,255}:palette==3?Color{175,180,155,255}:Color{205,160,145,255}; buildings.push_back(b); }
    }
    for(int i=0;i<45;i++){ Traffic v; v.axis=GetRandomValue(0,1); v.dir=GetRandomValue(0,1)?1:-1; v.speed=RandF(8,17); v.kind=GetRandomValue(0,4); v.color=(v.kind==1)?Color{220,190,20,255}:Color{(unsigned char)GetRandomValue(50,240),(unsigned char)GetRandomValue(50,240),(unsigned char)GetRandomValue(50,240),255}; float lane=GetRandomValue(-GRID/2,GRID/2)*ROAD_SPACING+(v.dir>0?4:-4); v.pos=v.axis==0?Vector3{RandF(-WORLD_HALF,WORLD_HALF),0,lane}:Vector3{lane,0,RandF(-WORLD_HALF,WORLD_HALF)}; traffic.push_back(v); }
    for(int i=0;i<100;i++){Person n; do{n.pos={RandF(-WORLD_HALF,WORLD_HALF),0,RandF(-WORLD_HALF,WORLD_HALF)};}while(OnRoad(n.pos.x,n.pos.z)); n.vel={0,0,0}; n.color={ (unsigned char)GetRandomValue(60,240),(unsigned char)GetRandomValue(60,240),(unsigned char)GetRandomValue(60,240),255}; n.timer=RandF(0.5f,3); people.push_back(n);}
    for(int i=0;i<24;i++){Animal a; do{a.pos={RandF(-WORLD_HALF,WORLD_HALF),0,RandF(-WORLD_HALF,WORLD_HALF)};}while(OnRoad(a.pos.x,a.pos.z)); a.vel={0,0,0}; a.timer=RandF(1,4); animals.push_back(a);}
    Camera3D camera{}; camera.up={0,1,0}; camera.fovy=65; camera.projection=CAMERA_PERSPECTIVE;
    TouchUI ui; bool garageOpen=false, missionActive=false, gameOver=false; float wanted=0, crimeQuiet=0, copSpawn=0, heliTimer=0, gameTime=0, missionTime=0, ambientTimer=0; int wantedLevel=0, score=0, missionStage=0; Vector3 target={260,0,260}; const char* missionName="DELIVER TO THE MARKET"; bool missionComplete=false;
    Sound engineSound={0}, ambientSound={0};
    // Procedurally generated short engine-like loop and ambient chirp; no audio files required.
    const unsigned int rate=22050, frames=rate/2; short *pcm=(short*)MemAlloc(frames*sizeof(short));
    for(unsigned int i=0;i<frames;i++){float tt=(float)i/rate; pcm[i]=(short)(sinf(2*PI*(72+22*sinf(tt*2*PI))*tt)*3500.0f*(0.6f+0.4f*sinf(tt*2*PI*2)));}
    Wave ew={frames,rate,16,1,pcm}; engineSound=LoadSoundFromWave(ew); MemFree(pcm); SetSoundVolume(engineSound,0.18f); PlaySound(engineSound);
    const unsigned int chirpFrames=rate/5; short *chirp=(short*)MemAlloc(chirpFrames*sizeof(short)); for(unsigned int i=0;i<chirpFrames;i++){float tt=(float)i/rate; chirp[i]=(short)(sinf(2*PI*(1200-500*tt)*tt)*1800.0f*(1.0f-(float)i/chirpFrames));} Wave aw={chirpFrames,rate,16,1,chirp}; ambientSound=LoadSoundFromWave(aw); MemFree(chirp); SetSoundVolume(ambientSound,0.22f);

    while(!WindowShouldClose()){
        float dt=GetFrameTime(); if(dt>0.05f)dt=0.05f; gameTime+=dt; int sw=GetScreenWidth(), sh=GetScreenHeight(); float scale=sh/720.0f; ui.steer=0;ui.throttle=0;ui.brake=false;ui.fire=false;ui.garage=false;ui.mission=false;
        Vector2 firePos={sw-82*scale,sh-100*scale}, brakePos={sw-185*scale,sh-70*scale}, garagePos={65*scale,55*scale}, missionPos={sw-82*scale,sh-220*scale}; float btnR=43*scale;
        int tc=GetTouchPointCount();
        for(int i=0;i<tc;i++){Vector2 p=GetTouchPosition(i); if(Vector2Distance(p,firePos)<btnR)ui.fire=true; if(Vector2Distance(p,brakePos)<btnR)ui.brake=true; if(Vector2Distance(p,garagePos)<btnR)ui.garage=true; if(Vector2Distance(p,missionPos)<btnR)ui.mission=true;}
        if(ui.joyActive){bool found=false;for(int i=0;i<tc;i++)if(GetTouchPointId(i)==ui.joyId){ui.joyKnob=GetTouchPosition(i);found=true;break;}if(!found){ui.joyActive=false;ui.steer=ui.throttle=0;}}
        if(!ui.joyActive)for(int i=0;i<tc;i++){Vector2 p=GetTouchPosition(i);if(p.x<sw*0.52f && Vector2Distance(p,firePos)>btnR && Vector2Distance(p,brakePos)>btnR){ui.joyActive=true;ui.joyId=GetTouchPointId(i);ui.joyBase=ui.joyKnob=p;break;}}
        if(ui.joyActive){Vector2 d=Vector2Subtract(ui.joyKnob,ui.joyBase);float len=Vector2Length(d),r=70*scale;if(len>r)d=Vector2Scale(d,r/len);ui.steer=ClampF(d.x/r,-1,1);ui.throttle=ClampF(-d.y/r,-1,1);ui.joyKnob=Vector2Add(ui.joyBase,d);}
        if(IsKeyDown(KEY_W)||IsKeyDown(KEY_UP))ui.throttle=1; if(IsKeyDown(KEY_S)||IsKeyDown(KEY_DOWN))ui.throttle=-1; if(IsKeyDown(KEY_A)||IsKeyDown(KEY_LEFT))ui.steer=-1; if(IsKeyDown(KEY_D)||IsKeyDown(KEY_RIGHT))ui.steer=1; if(IsKeyDown(KEY_SPACE))ui.fire=true; if(IsKeyDown(KEY_LEFT_SHIFT))ui.brake=true; if(IsKeyPressed(KEY_G))garageOpen=!garageOpen; if(IsKeyPressed(KEY_M))ui.mission=true;
        static bool garageTouchLatch=false; if(ui.garage && !garageTouchLatch) garageOpen=!garageOpen; garageTouchLatch=ui.garage;
        if(IsKeyPressed(KEY_ESCAPE))garageOpen=!garageOpen;
        if(gameOver){if(IsKeyPressed(KEY_ENTER)||ui.fire){player=Player{};wanted=0;wantedLevel=0;cops.clear();bullets.clear();gameOver=false;score=0;player.health=100;} BeginDrawing();ClearBackground(Color{18,22,32,255});DrawText("BUSTED",sw/2-130,sh/2-60,60,RED);DrawText(TextFormat("Score %d   Money $%d",score,saveData.money),sw/2-150,sh/2+10,24,WHITE);DrawText("Tap FIRE / press ENTER to restart",sw/2-190,sh/2+60,20,YELLOW);EndDrawing();continue;}
        if(garageOpen){BeginDrawing();ClearBackground(Color{17,22,34,255});DrawText("CITY GARAGE",40,24,36,GOLD);DrawText(TextFormat("MONEY: $%d",saveData.money),40,68,22,GREEN);DrawText("Tap a row to buy/equip | Upgrade: tap equipped car again",40,105,18,LIGHTGRAY);
            for(int i=0;i<4;i++){int y=145+i*112;bool owned=(saveData.owned>>i)&1;bool current=saveData.car==i;DrawRectangle(28,y,sw-56,94,current?Fade(GOLD,0.25f):Fade(DARKGRAY,0.5f));DrawRectangleLines(28,y,sw-56,94,current?GOLD:GRAY);DrawText(CARS[i].name,45,y+12,24,CARS[i].color);DrawText(TextFormat("Top speed %.0f | Upgrade level %d",CARS[i].maxSpeed+saveData.upgrades*3,saveData.upgrades),45,y+49,18,WHITE);DrawText(current?"EQUIPPED":owned?"TAP TO EQUIP":TextFormat("BUY $%d",CARS[i].price),sw-250,y+30,20,owned?GREEN:(saveData.money>=CARS[i].price?YELLOW:RED));}
            DrawText("GARAGE: tap top-left or press ESC to return",40,sh-40,18,LIGHTGRAY);
            if(IsMouseButtonPressed(MOUSE_BUTTON_LEFT)){Vector2 p=GetMousePosition();for(int i=0;i<4;i++){Rectangle row={28,(float)(145+i*112),(float)(sw-56),94};if(CheckCollisionPointRec(p,row)){bool own=(saveData.owned>>i)&1;if(!own&&saveData.money>=CARS[i].price){saveData.money-=CARS[i].price;saveData.owned|=1<<i;saveData.car=i;}else if(own&&saveData.car!=i)saveData.car=i;else if(own&&saveData.car==i&&saveData.money>=1000){saveData.money-=1000;saveData.upgrades=std::min(10,saveData.upgrades+1);}SaveGame();}}}
            if(tc>0){Vector2 p=GetTouchPosition(0);for(int i=0;i<4;i++){Rectangle row={28,(float)(145+i*112),(float)(sw-56),94};if(CheckCollisionPointRec(p,row)){static int lastTouch=-1;if(GetTouchPointId(0)!=lastTouch){lastTouch=GetTouchPointId(0);bool own=(saveData.owned>>i)&1;if(!own&&saveData.money>=CARS[i].price){saveData.money-=CARS[i].price;saveData.owned|=1<<i;saveData.car=i;}else if(own&&saveData.car!=i)saveData.car=i;else if(own&&saveData.car==i&&saveData.money>=1000){saveData.money-=1000;saveData.upgrades=std::min(10,saveData.upgrades+1);}SaveGame();}}}}
            EndDrawing();continue;}
        const CarSpec &cs=CARS[saveData.car]; float maxSp=cs.maxSpeed+saveData.upgrades*3.0f, accel=cs.accel+saveData.upgrades*1.0f;
        player.speed+=ui.throttle*accel*dt; player.speed-=player.speed*(ui.brake?4.5f:1.0f)*dt; player.speed=ClampF(player.speed,-maxSp*0.35f,maxSp);
        if(fabsf(player.speed)>0.7f)player.yaw+=ui.steer*cs.handling*dt*(player.speed>=0?1:-1)*(0.35f+fabsf(player.speed)/maxSp);
        Vector3 f=Forward(player.yaw); player.pos.x+=f.x*player.speed*dt;player.pos.z+=f.z*player.speed*dt; player.pos.x=ClampF(player.pos.x,-WORLD_HALF+5,WORLD_HALF-5);player.pos.z=ClampF(player.pos.z,-WORLD_HALF+5,WORLD_HALF-5);
        if(!IsSoundPlaying(engineSound))PlaySound(engineSound);SetSoundPitch(engineSound,0.7f+fabsf(player.speed)/maxSp*1.4f);
        for(auto &v:traffic){if(v.axis==0){v.pos.x+=v.dir*v.speed*dt;if(v.pos.x>WORLD_HALF)v.pos.x=-WORLD_HALF;if(v.pos.x<-WORLD_HALF)v.pos.x=WORLD_HALF;v.pos.z=roundf(v.pos.z/ROAD_SPACING)*ROAD_SPACING;}else{v.pos.z+=v.dir*v.speed*dt;if(v.pos.z>WORLD_HALF)v.pos.z=-WORLD_HALF;if(v.pos.z<-WORLD_HALF)v.pos.z=WORLD_HALF;v.pos.x=roundf(v.pos.x/ROAD_SPACING)*ROAD_SPACING;}if(DistXZ(v.pos,player.pos)<3.3f){player.health-=8*dt;player.speed*=0.94f;}}
        for(auto &n:people){n.timer-=dt;if(n.timer<=0){float a=RandF(0,2*PI),s=RandF(0.4f,1.8f);n.vel={cosf(a)*s,0,sinf(a)*s};n.timer=RandF(1,4);}n.pos=Vector3Add(n.pos,Vector3Scale(n.vel,dt));if(fabsf(n.pos.x)>WORLD_HALF||fabsf(n.pos.z)>WORLD_HALF||OnRoad(n.pos.x,n.pos.z))n.vel={0,0,0};}
        for(auto &a:animals){a.timer-=dt;if(a.timer<=0){float an=RandF(0,2*PI),s=RandF(0.5f,2);a.vel={cosf(an)*s,0,sinf(an)*s};a.timer=RandF(1,4);}a.pos=Vector3Add(a.pos,Vector3Scale(a.vel,dt));if(fabsf(a.pos.x)>WORLD_HALF||fabsf(a.pos.z)>WORLD_HALF||OnRoad(a.pos.x,a.pos.z))a.vel={0,0,0};}
        if(ui.fire){wanted=std::min(150.0f,wanted+0.15f);crimeQuiet=0;}
        wantedLevel=std::min(5,(int)(wanted/30.0f));crimeQuiet+=dt;if(crimeQuiet>8&&wanted>0)wanted=std::max(0.0f,wanted-2.5f*dt);wantedLevel=std::min(5,(int)(wanted/30.0f));
        copSpawn-=dt;int copTarget=wantedLevel*2;if(wantedLevel>0&&copSpawn<=0&&(int)cops.size()<copTarget){float a=RandF(0,2*PI),r=RandF(35,55);Cop c;c.pos={ClampF(player.pos.x+cosf(a)*r,-WORLD_HALF,WORLD_HALF),0,ClampF(player.pos.z+sinf(a)*r,-WORLD_HALF,WORLD_HALF)};c.yaw=atan2f(player.pos.x-c.pos.x,player.pos.z-c.pos.z);c.fireTimer=RandF(1,2);cops.push_back(c);copSpawn=2.0f;}
        for(int i=(int)cops.size()-1;i>=0;i--){Cop &c=cops[i];Vector3 d=Vector3Subtract(player.pos,c.pos);float dist=DistXZ(player.pos,c.pos);float desired=atan2f(d.x,d.z),diff=WrapAngle(desired-c.yaw);c.yaw+=ClampF(diff,-2.4f*dt,2.4f*dt);c.speed+=(ClampF(dist*0.7f,8,22)-c.speed)*dt*1.5f;Vector3 cf=Forward(c.yaw);c.pos.x+=cf.x*c.speed*dt;c.pos.z+=cf.z*c.speed*dt;c.fireTimer-=dt;if(dist<27&&c.fireTimer<=0){Vector3 dir=Vector3Normalize(d);bullets.push_back({Vector3Add(c.pos,{0,1.0f,0}),Vector3Scale(dir,27),2,false});c.fireTimer=1.3f;}if(dist<3.0f)player.health-=5*dt;}
        for(int i=(int)bullets.size()-1;i>=0;i--){bullets[i].pos=Vector3Add(bullets[i].pos,Vector3Scale(bullets[i].vel,dt));bullets[i].life-=dt;if(!bullets[i].player&&DistXZ(bullets[i].pos,player.pos)<1.8f){player.health-=12;bullets[i].life=0;}if(bullets[i].life<=0)bullets.erase(bullets.begin()+i);}
        heliTimer+=dt;Vector3 heliPos={player.pos.x+sinf(heliTimer)*18,18,player.pos.z+cosf(heliTimer)*18};
        if(ui.mission&&!missionActive){missionActive=true;missionComplete=false;missionStage=0;missionTime=75;target={RandF(-WORLD_HALF+40,WORLD_HALF-40),0,RandF(-WORLD_HALF+40,WORLD_HALF-40)};missionName="DELIVERY: REACH THE MARKET";}
        if(missionActive){missionTime-=dt;if(DistXZ(player.pos,target)<8){missionActive=false;missionComplete=true;saveData.money+=500+missionStage*100;score+=500;SaveGame();}if(missionTime<=0)missionActive=false;}
        if(player.health<=0){player.health=0;gameOver=true;saveData.highScore=std::max(saveData.highScore,score);SaveGame();}
        camera.position={player.pos.x-f.x*13,player.pos.y+7.5f,player.pos.z-f.z*13};camera.target={player.pos.x,player.pos.y+1.2f,player.pos.z};
        BeginDrawing();ClearBackground(Color{125,185,220,255});BeginMode3D(camera);
        DrawPlane({0,-0.08f,0},{WORLD_HALF*2,WORLD_HALF*2},Color{82,132,77,255});
        // Roads and dashed lane markings form a traversable city grid.
        for(int i=-GRID/2;i<=GRID/2;i++){float p=i*ROAD_SPACING;DrawCube({p,0.01f,0},ROAD_WIDTH,0.04f,WORLD_HALF*2,Color{60,62,66,255});DrawCube({0,0.01f,p},WORLD_HALF*2,0.04f,ROAD_WIDTH,Color{60,62,66,255});for(float q=-WORLD_HALF;q<WORLD_HALF;q+=14){DrawCube({p,0.045f,q},0.18f,0.03f,6,YELLOW);DrawCube({q,0.045f,p},6,0.03f,0.18f,YELLOW);}}
        for(auto &b:buildings){DrawCube(b.pos,b.size.x,b.size.y,b.size.z,b.color);DrawCube({b.pos.x,b.pos.y+b.size.y/2+0.12f,b.pos.z},b.size.x*1.04f,0.25f,b.size.z*1.04f,Color{105,75,60,255});for(float yy=2;yy<b.size.y-1;yy+=3.0f){for(float xx=-b.size.x/2+1;xx<b.size.x/2-0.5f;xx+=3){DrawCube({b.pos.x+xx,yy,b.pos.z+b.size.z/2+0.03f},0.9f,1.1f,0.08f,SKYBLUE);}}}
        // Street trees.
        for(int i=0;i<150;i++){float x=sinf(i*12.989f)*WORLD_HALF*0.92f,z=cosf(i*78.233f)*WORLD_HALF*0.92f;if(OnRoad(x,z))continue;DrawCylinder({x,1.0f,z},0.28f,0.2f,2,6,BROWN);DrawSphere({x,3.0f,z},1.4f,DARKGREEN);}
        for(auto &v:traffic){float yaw=v.axis==0?(v.dir>0?PI/2:-PI/2):(v.dir>0?0:PI);float len=v.kind==1?7.0f:(v.kind==2?10.0f:4.0f),wid=v.kind==1?2.6f:(v.kind==2?2.8f:1.9f);DrawCar3D(v.pos,yaw,v.color,len,wid);if(v.kind==2){DrawCube({v.pos.x,v.pos.y+1.2f,v.pos.z},wid*0.75f,1.1f,len*0.65f,Color{180,210,220,255});}}
        for(auto &n:people)DrawPerson(n);for(auto &a:animals)DrawAnimal(a);for(auto &c:cops)DrawCop3D(c,gameTime);
        DrawCar3D(player.pos,player.yaw,cs.color);for(auto &b:bullets)DrawSphere(b.pos,0.22f,b.player?YELLOW:RED);
        if(wantedLevel>=3){DrawHeli(heliPos,gameTime);DrawLine3D({heliPos.x,heliPos.y-1,heliPos.z},player.pos,Fade(YELLOW,0.25f));}
        if(missionActive){DrawCylinder({target.x,1.0f,target.z},1.0f,1.0f,2,12,GOLD);DrawCylinderWires({target.x,1.0f,target.z},1.2f,1.2f,2,12,YELLOW);}
        EndMode3D();
        // HUD
        DrawRectangle(12,12,280,112,Fade(BLACK,0.60f));DrawText(TextFormat("SPEED  %03.0f km/h",fabsf(player.speed)*3.6f),25,23,22,WHITE);DrawText(TextFormat("HEALTH  %03.0f%%",player.health),25,53,20,player.health>35?GREEN:RED);DrawText(TextFormat("MONEY  $%d   SCORE %d",saveData.money,score),25,82,17,GOLD);
        for(int i=0;i<5;i++)DrawText(i<wantedLevel?"★":"☆",25+i*27,132,26,i<wantedLevel?RED:LIGHTGRAY);DrawMinimap(player,traffic,cops,sw);
        if(missionActive)DrawText(TextFormat("MISSION: %s  %.0fs",missionName,missionTime),sw/2-180,18,20,GOLD);else DrawText(missionComplete?"MISSION COMPLETE! + CASH":"Tap MISSION to start a delivery",sw/2-180,18,18,WHITE);
        auto button=[&](Vector2 p,const char* label,Color c){DrawCircleV(p,btnR,Fade(c,0.75f));DrawCircleLines((int)p.x,(int)p.y,btnR,WHITE);int fs=(int)(15*scale);DrawText(label,(int)(p.x-MeasureText(label,fs)/2),(int)(p.y-fs/2),fs,WHITE);};
        button(firePos,"ALARM",MAROON);button(brakePos,"BRAKE",DARKBLUE);button(garagePos,"GARAGE",DARKGRAY);button(missionPos,"MISSION",ORANGE);
        if(ui.joyActive||tc>0){DrawCircleV(ui.joyBase,70*scale,Fade(DARKGRAY,0.3f));DrawCircleV(ui.joyKnob,28*scale,Fade(WHITE,0.65f));}
        DrawText("WASD/ARROWS drive | SPACE boost | G garage | M mission",sw/2-250,sh-28,16,WHITE);
        EndDrawing();
        ambientTimer-=dt;if(ambientTimer<=0){if(!IsSoundPlaying(ambientSound))PlaySound(ambientSound);ambientTimer=RandF(4,9);} 
    }
    StopSound(engineSound);UnloadSound(engineSound);UnloadSound(ambientSound);CloseAudioDevice();CloseWindow();return 0;
}
